const categoriesController = require("../controllers/categories.controller");
const express = require("express");
const router = express.Router();

router.post("/category", categoriesController.create);
router.get("/category", categoriesController.findAll);
router.get("/category/:id", categoriesController.findOne);
router.put("/category/:id", categoriesController.update);
router.delete("/category/:id", categoriesController.delete);


module.exports = router;